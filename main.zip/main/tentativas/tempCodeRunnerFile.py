                           if boss_life_count == 0:
                                    fim = True

                    # contador de vidas do boss
                    for c in range(boss_life_c